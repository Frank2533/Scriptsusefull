import concurrent.futures
import json
import traceback

from pymongo import MongoClient
import pandas as pd
import scrapingbee
import csv
import os

from bs4 import BeautifulSoup
from tqdm import tqdm

import catcrawl_constants as const

client = scrapingbee.ScrapingBeeClient(api_key =const.SPB_API_KEY)
executor = concurrent.futures.ThreadPoolExecutor(max_workers=const.MAX_THREADS)

def rectify_url(url):
    if 'b?node=' in url:
        url = url.replace('b?node=','s?rh=n%3A')
    if 'b/?node=' in url:
        url = url.replace('b/?node=', 's?rh=n%3A')
    return url
    # b?node= -> s?rh=n%3A
    # b/?node= -> s?rh=n%3A


def read_input():
    df = pd.read_csv(const.input_file)
    data = df.to_dict('records')
    return data

def send_data_to_db(data):
    coll = const.coll
    if len(data)!=0:
        coll.insert_many(data)

def write_data(data=None, catname=None, headers = 0):
    if headers == 1:
        with open(f"{catname}_output.csv", "a", encoding="utf-8", newline="") as file:
            csvwriter = csv.writer(file)
            csvwriter.writerows(const.output_header)
    with open(f"catname_output.csv","a", encoding="utf-8", newline="") as file:
        csvwriter = csv.writer(file)
        csvwriter.writerows(data)


def send_data_to_pnf(data):
    client = MongoClient('mongodb://crawler:Cr%40wler%230822@172.16.34.39:27017/?authMechanism=DEFAULT')
    db = client['blackhawk_live']
    coll = db['Amazon_cat_Apr24_18_04_pnf']
    coll.insert_one(data)


def crawl_category(input):

    page = 0
    o_url = input["URL"]
    next_url = rectify_url(o_url)
    while next_url is not None:
        page+=1

        catname = input["Category"]
        resp, page = hit_page(next_url, page)
        if resp == "":

            resp, page = hit_page(next_url, page)
            if resp == "":
                temp_dict = {
                "catname": catname,
                "caturl": o_url,
                "page_url":next_url,
                "page": page.split('!@!')[-1],
                "Error": page.split('!@!')[0],

                }
                if len(page.split('!@!')) == 3:
                    temp_dict['response'] = resp.text
                send_data_to_pnf(temp_dict)
                del temp_dict
                next_url=None
                continue
        if resp!="" and page==1:
            with open(f"./cache/{catname}_{page}", "w", encoding="utf-8") as file:
                file.write(resp.text)
        conurl = 'https://www.amazon.com'
        soup = BeautifulSoup(resp.text, 'html.parser')
        prodlist = soup.select(const.css_selector)
        out_data = []
        for m in range(0, len(prodlist)):
            try:
                purl = conurl + prodlist[m].h2.a.attrs['href']
                # print(purl)
            except:
                try:
                    # print("urltry2")
                    purl = conurl + prodlist[m].select_one('span.a-declarative a').attrs['href']
                    # print(purl)
                except:
                    purl = ''
            # try:
            # mpn = prodlist[m].
            # print(prodlist)
            try:
                if 'slredirect' in purl.split('/'):
                    # print('sushil')
                    mpn = purl.split('/gp/')[-1].split('%2Fdp%2F')[1].split('%2F')[0]

                else:
                    mpn = purl.split('/dp/')[1].split('/')[0]

            except:
                mpn = ""
            # print(mpn)

            title = prodlist[m].h2.text
            # print(title)
            output = {
                "Pageno": str(page),
                "Rank": str(m + 1),
                "Category": catname,
                "Caturl": o_url,
                "Page_url":next_url,
                "Source": "Amazon_US",
                "Country": "US",
                "Product_Title": title,
                "MPN": mpn,
                "URL": purl
                    }
            out_data.append(output)
        send_data_to_db(out_data)
        next_url = soup.select_one('a[aria-label*="next page"]')
        if next_url is not None:
            next_url = conurl+next_url.get('href')




def hit_page(url, page, retry = 0):
    scraper = scrapingbee.ScrapingBeeClient(
        api_key=const.SPB_API_KEY)
    try:
        # Productpage_resp1 = scraper.get(url, proxies=proxy, headers=headers, timeout=120)
        resp = scraper.get(url,params={'block_resources': False, 'premium_proxy': 'True', 'render_js': False, 'timeout':10000})
    except Exception as e:
        print(e)
        retry+=1
        if retry<=3:
            resp, page = hit_page(url, page, retry)
            try:
                print("Got E page after ", retry, " retries")
            except AttributeError:
                print("Got blank resp after ", retry, " retries")
            return resp, page
        else:

            return "", str(traceback.format_exc())+"!@!"+str(page)

    if resp.status_code==200:
        return resp, page
    else:
        retry += 1
        if retry <= 3:
            resp, page = hit_page(url, page, retry)
            try:
                print(f"Got {resp.status_code} page after ", retry, " retries")
            except AttributeError:
                print("Got blank resp after ", retry, " retries")
            return resp, page
        else:
            if resp:
                return "", str(traceback.format_exc())+"!@!"+str(page)+'!@!'+resp.text
            else:
                return "", f"status_code={resp.status_code}!@!{page}"


def main():
    data = read_input()
    fut_list = []

    for input in tqdm(data, desc="Allocation"):
        fut_list.append(executor.submit(crawl_category,input))
    pbar = tqdm(fut_list, desc="Main progress")
    for fut in concurrent.futures.as_completed(fut_list):
        pbar.update(1)

main()