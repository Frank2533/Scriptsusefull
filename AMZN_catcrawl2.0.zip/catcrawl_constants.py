from pymongo import MongoClient

input_file = "catcrawl.csv"
css_selector = 'div[cel_widget_id*="MAIN-SEARCH_RESULTS"][data-csa-c-type="item"]'
output_folder = "Catcrawl_output"

MAX_THREADS = 400
prodperpage = 24
SPB_API_KEY = "VQX6F0YAKGDTKZG4ET37S5S0K4QIV4EQV88NFLKKYMONJ9SEYVH0BDOYSE5CZF0B3WA8BN58KKGUOATT"

output_header = ["PageNumber",
                 "Record_no",
                 "Category",
                 "Website",
                 "Country",
                 "Name",
                 "Description",
                 "Brand",
                 "MPN",
                 "producturl",
                 "Timestamp", ]

client = MongoClient('mongodb://crawler:Cr%40wler%230822@172.16.34.39:27017/?authMechanism=DEFAULT')
db = client['blackhawk_live']
coll = db['Amazon_cat_Apr24_18_04']
