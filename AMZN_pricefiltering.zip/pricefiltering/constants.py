from pymongo import MongoClient

host = '172.16.34.39'
port_m = '27017'
MONGO_USER = "crawler"
MONGO_PASS = "Cr%40wler%230822"  # "Cr@wler#0822"
db = 'Amazon_catcrawl_test'
# con = pymongo.MongoClient(f'mongodb://{host}:{port_m}/')
con = MongoClient(f"mongodb://{MONGO_USER}:{MONGO_PASS}@{host}:{port_m}/?authMechanism=DEFAULT")
mydb = con[db]
CONN_OUTPUT = mydb['amazon_catcrawl_output_13_04']
# CONN_OUTPUT = mydb['pedidosya_list_output_14_jan']
CONN_INPUT = mydb['Amazon_cattrace_input_blackhawk']

SPF_API_KEY = "scp-live-3e1b1a21c541451ea7586e949c6dc619"

MAX_THREADS = 1
MAX_THREADS_INTERVALS = 10
max_price_selector = 'div[cel_widget_id*="MAIN-SEARCH_RESULTS"] span.a-price-whole'