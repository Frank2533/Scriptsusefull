import re
from dataclasses import dataclass, field

@dataclass
class Catclass:

    URL:str = ""
    catpath:str = ""
    prodperpage:int = 0
    totalprod:int = 0
    intervals:list = field(default_factory=list)
    catpagesurls:list = field(default_factory=list)
    json_data:list = field(default_factory=list)
    intervalhalfs:int = 0
    cat_initial_data:dict = field(default_factory=dict)
    finalise_intervals:list = field(default_factory=list)
    crawl_pages:list = field(default_factory=list)
    ids_invalid:list = field(default_factory=list)
    pnf:list = field(default_factory=list)

    def refineurl(self):

        self.URL = self.URL.replace("\\u0026","&")
        val_pre = None
        valdel = []
        temp_price = self.URL.split('&')

        for ind in range(len(temp_price)-1,0, -1):
            if "price" in temp_price[ind]:
                val_pre = ind
            if val_pre is not None and "price" in temp_price[ind]:
                valdel.append(ind)
        [temp_price.pop(x) for x in valdel]
        self.URL = '&'.join(temp_price)
        self.URL = re.sub(r"%2Cp_36*&","&",self.URL)
        self.URL = self.URL.replace("b?node=","s?rh=n%3A")
        # self.URL = self.URL.split('&qid')[0]
        if "&fs=true" not in self.URL:
            self.URL += "&fs=true"



