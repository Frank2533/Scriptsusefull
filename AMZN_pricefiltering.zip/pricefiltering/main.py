import concurrent.futures
import json
import traceback
from dataclasses import asdict

from tqdm import tqdm

from amazon_class import Catclass
import constants
import dbops
import request_handler as req
executor_main = concurrent.futures.ProcessPoolExecutor(max_workers=constants.MAX_THREADS)
executor_intervals = concurrent.futures.ThreadPoolExecutor(max_workers=constants.MAX_THREADS_INTERVALS)


def main(input):
    global Catobj
    Catobj = Catclass(URL=input["data__url"], catpath=input["data__catpath"], prodperpage=input['data__perpagecount'])
    try:
        Catobj.refineurl()
        Catobj = req.first_hit(Catobj)
        print("Length intervals = ", len(Catobj.cat_initial_data["IntervalUrls"]))
        print("Length invalid = ", len(Catobj.ids_invalid))
        old_value = 0
        # old_value = len(Catobj.ids_invalid) - len(Catobj.cat_initial_data["IntervalUrls"])
        while (len(Catobj.ids_invalid)!=len(Catobj.cat_initial_data["IntervalUrls"])):
            fut_list = []

            for index, value in enumerate(Catobj.cat_initial_data["IntervalUrls"]):
                print("Length intervals = ", len(Catobj.cat_initial_data["IntervalUrls"]))
                print("Length invalid = ", len(Catobj.ids_invalid))


                if index in Catobj.ids_invalid:
                    continue
                else:
                    if value["interval"]<=0.5:
                        Catobj.crawl_pages.append(value['url'])
                        Catobj.ids_invalid.append(index)
                    fut_list.append(executor_intervals.submit(req.second_hit,index,Catobj))
            new_value = len(fut_list)
            pbar = tqdm(total = len(fut_list), desc="Working")
            for fut in concurrent.futures.as_completed(fut_list):
                try:
                    Catobj = fut.result()
                    pbar.update(1)
                except Exception as e:
                    print(traceback.format_exc())
            if old_value == new_value:
                break
            # old_value = new_value
            # new_value = len(Catobj.ids_invalid) - len(Catobj.cat_initial_data["IntervalUrls"])
            # if old_value==new_value:
            #     break
            old_value = new_value
            with open('output.json', 'w', encoding="utf-8") as file:
                file.write(json.dumps(asdict(Catobj)))
        dbops.send_output(asdict(Catobj))
    except:
        print(traceback.format_exc())


if __name__ == '__main__':
    inputs = dbops.get_input()
    fut_list = []
    pbar1 = tqdm(total=len(inputs))
    for input in inputs:

        try:
            fut_list.append(executor_main.submit(main, input))

        except:
            print(traceback.format_exc())
    for fut in concurrent.futures.as_completed(fut_list):
        pbar1.update(1)