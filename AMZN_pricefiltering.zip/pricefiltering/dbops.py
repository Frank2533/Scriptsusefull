import constants

def get_input():
    input = [x for x in constants.CONN_INPUT.find({"data__count":{"$ne":0}})]
    return input

def send_output(data):
    constants.CONN_OUTPUT.insert_one(data)