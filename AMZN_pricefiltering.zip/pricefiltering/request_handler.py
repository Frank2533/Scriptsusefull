import datetime
import json
import os
import time
import random
import socket
import traceback
import urllib
import requests
# import requests_handler
import scrapingbee
from scrapfly import ScrapflyClient, ScrapeConfig, ScrapeApiResponse
import dbops
from amazon_class import Catclass
import constants
import threading
import hashlib
import cat_parser

spf_client = ScrapflyClient(key=constants.SPF_API_KEY)

def make_first_hit_json(result, catobj):
    catobj.cat_initial_data = result.result['result']['browser_data']['javascript_evaluation_result']
    catobj = cat_parser.initial_json(catobj)
    return catobj

def first_hit(catobj:Catclass ):
    js = """
    let interval = 0;
let data = {
  "MainCatURL":document.URL,
  "MaxPrice":0,
  "MinPrice":0,
  "StartPartitionPrice":0,
  "EndPartitionPrice":0,
  "TotalNoofProd":0,
  "IntervalUrls":[],
  "Price_list":null,
  "interval":0
};


function get_max_min_price(){
    let max_price = 0;
    let min_price = 0;
  const prices2 = document.querySelectorAll('div[data-cel-widget*="search_result"]:not([class*="AdHolder"]) span.a-price-whole');
    let prices = [];
    prices2.forEach(function(item){
        prices.push(item.textContent.replace(",","").replace(".","").trim());
    })
    data["Price_list"] = prices;
  if (prices.length >= 2)
  {
      console.log("in");
      prices = prices.map(Number);
      prices.sort((a, b) => b - a);
      prices = prices.map(String);
    if (prices[0].length > 0)
    {
      max_price = prices[0];
    }
    if (prices[prices.length-1].length > 0)
    {
      min_price = prices[prices.length-1];
    }
  }else{
    max_price = 0;
    min_price = 0;
  } 
  return {"max_price":max_price, "min_price":min_price};
}
function get_interval(number2) {
    let number = Number(number2);
    let interval = 0;
    if (number <= 1) {
        interval =  0.2;
    } else if (number <= 10) {
        interval =  1;
    } else if (number <= 100) {
        interval =  10;
    } else if (number <= 1000) {
        interval =  100;
    } else if (number <= 10000) {
        interval =  1000;
    } else if (number <= 100000) {
        interval =  10000;
    } else if (number <= 1000000) {
        interval =  100000;
    } else {
        // Add more conditions as needed for larger numbers
        interval =  0; // Indicate that the number is out of range
    }  
    data["interval"] = interval;
    interval =  interval;
    return interval;
}
function get_interval_urls(interval, start_price, min_price, end_price) {
    let intervalUrls = [];

    // Loop through the price range and create intervals
    for (let i = start_price; i <= min_price; i += interval) {
        let intervalEnd = Math.min(i + interval, min_price); // Adjust interval end
        let intervalString = `&price=${i * 100}-${intervalEnd * 100}`;
        intervalUrls.push({url:intervalString, startprice:i, endprice:intervalEnd, totalprod:0, interval:interval});
    }
	let lasturl = `&price=${min_price * 100}-${end_price * 100}`;
  intervalUrls.push({url:lasturl, startprice:min_price, endprice:end_price, interval:interval})
    // Append intervals to document.URL
    let newURL = document.URL;
    intervalUrls.forEach(interval => {
        interval.url = newURL + interval.url;
    });
    //console.log(intervalUrls);
    return intervalUrls;
}
function parsehtml(){
    function parsecatpathitem(catpathitem) {
      let catlist = [];
      let parentcats = catpathitem.querySelectorAll('li  a:has(span.s-back-arrow)');
      console.log(parentcats)
      for (let cat of parentcats){
          catlist.push(cat.innerText.trim());
      }
      let catnow = catpathitem.querySelector('li:not(:has(a)) span.a-text-bold');
      catlist.push(catnow.innerText.trim());
      let catpath = catlist.join(' > ');
      return catpath;
  }
  let totalele = null;
  
  document.querySelectorAll('script').forEach(function(item){
    if (item.textContent){
    if (item.textContent.includes('totalResultCount')){
        totalele = JSON.parse(item.textContent.split("P.declare('s\\\\-metadata',")[1].split(");")[0].replace(/\\\\/g,''))
        //console.log(item.textContent)
    }}
    // console.log(item.textContent.includes('totalResultCount'));
	});
	let count = 0;
    let perpage = 0;
	let endpage = 0;
	let catpath = "";
    let subcatdata = 0;
	if (totalele){
      count = totalele['totalResultCount'];
      data["TotalNoofProd"]=count;
      perpage = totalele['asinOnPageCount'];
      data["perpagecount"]=perpage;
    }else{
      count=0;
      perpage=0;
    }
	if (Math.floor(count/perpage) <= 400){
      endpage = 1;
    }
  	if (count == 0){
      endpage = 0;
    }
  	if (Math.floor(count/perpage) > 400){
      endpage = 2;
    }
	let catpathitem = null;
    
	document.querySelectorAll('div[id="departments"] span[data-csa-c-slot-id="nav-pkr"]').forEach(function(item){
    if (item.querySelectorAll('li').length>1){
        catpathitem = item;
    }
	})
	
	if (catpathitem){
      catpath = parsecatpathitem(catpathitem);
    }
	
	return { crawl:endpage, catpath:catpath, };
}

  
  
function driveScrape(){
    data2 = parsehtml();
    prices_data = get_max_min_price();
  max_price = prices_data.max_price;
      min_price =  prices_data.min_price;
  data["MaxPrice"] = max_price;
  data["MinPrice"] = min_price;
  data["EndPartitionPrice"] = max_price;
  if (data2["crawl"] == 2){
  interval = get_interval(min_price);
  //console.log(data);
  let interval_urls = get_interval_urls(interval, 0,Number(min_price), Number(max_price));
  data["IntervalUrls"] = interval_urls;}
  
  data = {...data, ...data2}; 

}

driveScrape();
//localStorage.setItem("data",JSON.stringify(data));
return data;
    """
    for _ in range(3):
        result: ScrapeApiResponse = spf_client.scrape(ScrapeConfig(
            tags={
                f"AmazonCatCrawl",
            },
            # timeout=30000,
            debug=True,
            country="us",
            js=js,
            asp=True,
            render_js=True,
            rendering_wait=3000,
            method="GET",
            url=catobj.URL+"&s=price-desc-rank",
            # proxy_pool="public_residential_pool",
        ))
        if result.response.status_code == 200:
            catobj = make_first_hit_json(result, catobj)
            # catobj.json_data = {"First_hit":json}
            return catobj
        else:
            continue

def make_second_hit_json(result, catobj, id):
    if result.result['result']['browser_data']['javascript_evaluation_result']['crawl']==1:
        catobj.crawl_pages.append(catobj.cat_initial_data['IntervalUrls'][id]['url'])
        catobj.ids_invalid.append(id)
    elif result.result['result']['browser_data']['javascript_evaluation_result']['crawl']==0:
        catobj.pnf.append(catobj.cat_initial_data['IntervalUrls'][id])
        catobj.ids_invalid.append(id)
    else:
        catobj.cat_initial_data['IntervalUrls'].extend(result.result['result']['browser_data']['javascript_evaluation_result']['IntervalUrls'])
        catobj.ids_invalid.append(id)
    return catobj


def second_hit(id, catobj):
    try:
        catobj.refineurl()
        # print(catobj.URL)
        input_json = catobj.cat_initial_data['IntervalUrls'][id]
        js = """
        let interval = 0;
    let data = {
      "MainCatURL":document.URL,
      "CatUrl":"%s",
      "MaxPrice":%d,
      "MinPrice":%d,
      "StartPartitionPrice":%d,
      "EndPartitionPrice":%d,
      "TotalNoofProd":0,
      "IntervalUrls":[],
      "Price_list":null,
      "interval":%d
    };
    
    
    function get_interval(number2) {
        let interval = 0;
        let number = Number(number2);
        if (number <= 1) {
            interval =  0.2;
        } else if (number <= 10) {
            interval =  1;
        } else if (number <= 100) {
            interval =  10;
        } else if (number <= 1000) {
            interval =  100;
        } else if (number <= 10000) {
            interval =  1000;
        } else if (number <= 100000) {
            interval =  10000;
        } else if (number <= 1000000) {
            interval =  100000;
        } else {
            // Add more conditions as needed for larger numbers
            interval =  0; // Indicate that the number is out of range
        }  
        data["interval"] = interval;
        
        return interval;
    }
    
    function get_interval_urls(interval, start_price, min_price, end_price) {
        let intervalUrls = [];
    
        // Loop through the price range and create intervals
        for (let i = start_price; i < max_price; i += interval) {
            let intervalEnd = Math.min(i + interval, max_price); // Adjust interval end
            let intervalString = `&price=${i * 100}-${intervalEnd * 100}`;
            intervalUrls.push({url:intervalString, startprice:i, endprice:intervalEnd,totalprod:0, interval:interval});
        }
        // let lasturl = `&price=${min_price * 100}-${end_price * 100}`;
     //  intervalUrls.push({url:lasturl, startprice:min_price, endprice:end_price, interval:interval})
        // Append intervals to document.URL
        let newURL = document.URL;
        intervalUrls.forEach(interval => {
            interval.url = data["CatUrl"] + interval.url;
        });
        //console.log(intervalUrls);
        return intervalUrls;
    }
    function parsehtml(){
        function parsecatpathitem(catpathitem) {
          let catlist = [];
          let parentcats = catpathitem.querySelectorAll('li  a:has(span.s-back-arrow)');
          console.log(parentcats)
          for (let cat of parentcats){
              catlist.push(cat.innerText.trim());
          }
          let catnow = catpathitem.querySelector('li:not(:has(a)) span.a-text-bold');
          catlist.push(catnow.innerText.trim());
          let catpath = catlist.join(' > ');
          return catpath;
      }
      let totalele = null;
      
      document.querySelectorAll('script').forEach(function(item){
        if (item.textContent){
        if (item.textContent.includes('totalResultCount')){
            totalele = JSON.parse(item.textContent.split("P.declare('s\\\\-metadata',")[1].split(");")[0].replace(/\\\\/g,''))
            //console.log(item.textContent)
        }}
        // console.log(item.textContent.includes('totalResultCount'));
        });
        let count = 0;
        let perpage = 0;
        let endpage = 0;
        let catpath = "";
        let subcatdata = 0;
        if (totalele){
          count = totalele['totalResultCount'];
          data["TotalNoofProd"]=count;
          perpage = totalele['asinOnPageCount'];
          data["perpagecount"]=perpage;
          data["total_data_json"]=totalele
        }else{
          count=0;
          perpage=0;
        }
        if (Math.floor(count/perpage) <= 400){
          endpage = 1;
        }
        if (count == 0){
          endpage = 0;
        }
        if (Math.floor(count/perpage) > 400){
          endpage = 2;
        }
        let catpathitem = null;
        
        document.querySelectorAll('div[id="departments"] span[data-csa-c-slot-id="nav-pkr"]').forEach(function(item){
        if (item.querySelectorAll('li').length>1){
            catpathitem = item;
        }
        })
        
        if (catpathitem){
          catpath = parsecatpathitem(catpathitem);
        }
        
        return { crawl:endpage, catpath:catpath, };
    }
    
      
      
    function driveScrape(){
      data2 = parsehtml();
        min_price = data["StartPartitionPrice"];
        max_price = data["EndPartitionPrice"]
      if (data2["crawl"] == 2){
          interval = get_interval(data["interval"])
          let interval_urls = get_interval_urls(interval, min_price, min_price, max_price);
          data["IntervalUrls"] = interval_urls;
      }
      
      
      data = {...data, ...data2}; 
    
    }
    
    driveScrape();
    return data;
    
    
        """%(catobj.URL,int(input_json['endprice']), int(input_json['startprice']), int(input_json['startprice']), int(input_json['endprice']), int(input_json['interval']))
        for _ in range(3):
            result: ScrapeApiResponse = spf_client.scrape(ScrapeConfig(
                tags={
                    f"AmazonCatCrawl",
                },
                # timeout=30000,
                debug=True,
                country="us",
                js=js,
                asp=True,
                render_js=True,
                rendering_wait=3000,
                method="GET",
                url=input_json['url']#.replace("&s=price-desc-rank",""),
                # proxy_pool="public_residential_pool",
            ))
            if result.response.status_code == 200:
                with open(f"{input_json['startprice']}_{input_json['endprice']}_{str(datetime.datetime.now()).replace('-','_').replace('.','_').replace(':','_')}.json", "w", encoding="utf-8") as file:
                    file.write(json.dumps(result.result['result']['browser_data']['javascript_evaluation_result']))
                catobj = make_second_hit_json(result, catobj, id)
                # catobj.json_data = {"First_hit":json}
                return catobj
            else:
                print(result.response.status_code)
                continue
    except Exception as e:
        print(traceback.format_exc())






