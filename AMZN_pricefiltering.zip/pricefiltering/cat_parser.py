import json

from amazon_class import Catclass


def initial_json( catobj:Catclass):
    if catobj.cat_initial_data["crawl"]==1:
        catobj.crawl_pages.append(catobj.URL)

    return catobj


